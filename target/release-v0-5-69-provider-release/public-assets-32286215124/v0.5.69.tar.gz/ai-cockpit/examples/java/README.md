---
author: Ray
title: "Java Adaptation Example"
description: Java stack adaptation example for AI Cockpit.
keywords:
  - java
  - ai-cockpit
  - ai-agents
  - governance
---

# Java Adaptation Example

## 1. インストール

```sh
: "${AI_COCKPIT_TEMPLATE_REF:?set AI_COCKPIT_TEMPLATE_REF to the release tag}"
: "${AI_COCKPIT_TEMPLATE_RAW_BASE:?set AI_COCKPIT_TEMPLATE_RAW_BASE to the matching raw-content base}"
sh -c "$(curl -fsSL "${AI_COCKPIT_TEMPLATE_RAW_BASE}/${AI_COCKPIT_TEMPLATE_REF}/install.sh")" -- --stack java --update-makefile --create-adoption
```

## 2. 品質ゲートとガード設定

Gradle ベースの Java リポジトリでは、`Makefile.ai.stack` に次のスタックプリセットを設定します。

```make
PROJECT_FORMAT_CHECK = ./gradlew spotlessCheck
PROJECT_TEST = ./gradlew test
PROJECT_LINT = ./gradlew check
```

Spring Boot 向けの `.ai/guards/coverage_policy.yaml` には、次のガードパターンを推奨します。

```yaml
production:
  include:
    - "src/main/**"
  exclude:
    - "**/*Test.java"     # JUnit テストクラス（Test で終わる）
    - "**/*Tests.java"    # JUnit テストクラス（Tests で終わる）
    - "**/*Spec.java"     # Spock など
    - "**/*IT.java"       # 結合テスト（Integration Test）

tests:
  include:
    - "src/test/**"
    - "**/*Test.java"
    - "**/*Tests.java"
    - "**/*Spec.java"
    - "**/*IT.java"
```

Android 向けの `.ai/guards/coverage_policy.yaml` には、次のガードパターンを推奨します。

```yaml
production:
  include:
    - "app/src/main/**"   # app モジュールの既定 production root
    - "*/src/main/**"     # マルチモジュール構成の production root
  exclude:
    - "**/*Test*.kt"
    - "**/*Test*.java"
    - "**/*Spec*.kt"

tests:
  include:
    - "app/src/test/**"          # app モジュールのローカル単体テスト
    - "app/src/androidTest/**"   # app モジュールの結合テスト（インストルメント）
    - "**/*Test*.kt"
    - "**/*Test*.java"
```

上の YAML は Android Java リポジトリの出発点です。テンプレート本体の `coverage_policy.yaml` デフォルトは変更せず、最初は `reportOnly: true` のままにして、実際の module / flavor / variant 境界を確認してから絞り込みます。`app/src/main/**` は app モジュールの主な production root、`*/src/main/**` はマルチモジュール向けの一般形、`app/src/test/**` と `app/src/androidTest/**` は最初に確認する test root です。Flavor 固有の source set がある場合は、`src/<flavor>/...` などの実際に存在する root を別途明示してください。

---

## 3. 実践的な Java 用 Contract 設計例 (`*.contract.json` 抜粋)

以下は、典型的な Java 機能追加時の Contract 設定例です。

```json
{
  "contractVersion": 2,
  "workItemId": "add_user_controller",
  "mode": "code",
  "scope": [
    "build.gradle",
    "src/main/java/com/example/controller/UserController.java",
    "src/test/java/com/example/controller/UserControllerTest.java"
  ],
  "guidelines": [
    "すべての新規コントローラークラスには Javadoc を記述すること",
    "テストカバレッジの警告が発生しないよう、対応するテストクラスを必ず同行させること"
  ],
  "verification": [
    { "check": "aiWorkItem", "required": true },
    { "check": "aiScope", "required": true },
    { "check": "aiGuards", "required": true },
    { "check": "aiCheckpoint", "required": true },
    { "check": "aiAgentRisk", "required": true },
    { "check": "aiReviewPolicy", "required": true },
    { "check": "aiBacktrack", "required": true },
    { "check": "aiCoverage", "required": true },
    { "check": "aiScenarioCoverage", "required": true },
    { "check": "aiGuidelines", "required": true },
    { "check": "aiSummary", "required": true },
    { "check": "aiStatus", "required": true },
    { "check": "aiStatusCheck", "required": true },
    { "check": "aiStatusConsistency", "required": true },
    { "check": "aiDiffOwnership", "required": true },
    { "check": "quality", "required": true }
  ]
}
```

---

## 4. guidelinesCompliance の記述例 (`*.summary.json` 抜粋)

上記ガイドラインに適合したことを証明する要約（Summary）の記述例です。

```json
{
  "guidelinesCompliance": [
    {
      "guideline": "すべての新規コントローラークラスには Javadoc を記述すること",
      "compliant": true,
      "evidence": "UserController.java 内のクラスおよび公開メソッドに Javadoc を追記しました。"
    },
    {
      "guideline": "テストカバレッジの警告が発生しないよう、対応するテストクラスを必ず同行させること",
      "compliant": true,
      "evidence": "UserControllerTest.java に新規エンドポイントの結合テストを追加し、カバレッジを確保しました。"
    }
  ]
}
```
