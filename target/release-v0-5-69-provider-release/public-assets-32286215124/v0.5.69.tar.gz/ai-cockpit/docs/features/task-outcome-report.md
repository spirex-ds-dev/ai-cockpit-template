---
author: Ray
title: Task Outcome Report
description: Evidence-backed reporting of what AI Cockpit changed, found, prevented, and left for human review.
---

# Task Outcome Report

Task Outcome answers “what value and evidence did AI Cockpit provide for this Work Item?” It is separate from Cockpit Status, which answers “can execution continue?”, and from the PR Summary, which is an optional sanitized reviewer presentation.

## Sources and structure

Machine truth is `.ai/work-items/active/<task>.outcome.json`. Its Markdown view is derived at `.ai/work-items/active/<task>.outcome.md`; archived Work Items retain the corresponding `outcome.json` and `outcome.md`. The pre-merge Outcome is rebuilt from Contract, Summary, verification, guards, risks, checkpoints, human confirmations, stops/resumes, changed files, tests, and archive evidence. It binds the exact base and Work Item head, and explicitly records that provider PR facts do not yet exist.

The report contains these sections: Outcome Summary, Task Overview, Delivered Changes, Findings, Risks, Warnings, Interventions, Forced Stops, Resolutions, Recurrence Prevention, Avoided Impact, Residual Risks, Human Decisions, and Evidence. Empty sections say `None`. Findings are evidence-backed and categorized; risks distinguish observed problems, potential risks, and prevented events. A Resolution links Problem → Action → Verification → Result.

New generator versions also include `humanHandoff`. This is the mandatory conversational projection for every agent (Codex, Gemini, subagents, or another client), and it is emitted before archive. It contains `completed`, `passed`, `retained`, `risks`, `redReasons`, and the fixed human-question set: problem count, blocking problems, resolved problems, resolution approach, avoided risks, remaining risks, agent unknowns, human confirmations, recurrence likelihood, and next-time prevention. Every claim carries `evidenceRefs`; a claim with no references is explicitly marked `inference` and is not a fact. Red reasons include gate, cause, exact location, evidence, and recovery.

When a Summary records `observedIssues`, `ai-finish` projects an issue marked with a resolved/fixed/mitigated/accepted status into `resolvedProblems` and `resolutionApproach`, preserving that issue's evidence references. An issue without evidence is never presented as verified resolution; it remains visible as an inference/remaining risk. This projection is prospective and does not rewrite immutable historical archives.

The same structured records are also projected into the top-level sections: evidence-bound `resolutions` populate `Resolutions` with Problem, Action, Verification, Result, and evidence references; `handoffRisks` populate `Residual Risks` when their state is unresolved or accepted. Markdown renders the problem/risk detail instead of replacing it with a file path. Duplicate human-decision strings are reduced in first-seen order. Evidence-free records remain explicit `inference` and cannot become verified facts.

Observed issue handoff records use Summary `evidenceRefs` as the canonical evidence field. The pre-merge adapter preserves those references into `resolvedProblems`, `resolutionApproach`, and structured `resolutions`; legacy `evidence` remains a compatibility fallback, while missing or malformed references stay inference.

## Warning color semantics

`knownGaps` means an intentionally unaddressed requirement. Each genuine known gap becomes a Warning with a limitation binding and makes an otherwise completed Outcome `completed_with_warnings` (yellow). It must not be used as free-form completion commentary.

For an evidence-backed fact that is not an unresolved requirement—for example, that hosted verification is not required by the active Contract—use the optional Summary `nonRiskExplanations` field. Finish carries that structured explanation into the Non-Risk Explanations section without adding a Warning, limitation, or yellow status. The field requires a statement, reason, and source/subject evidence reference; malformed entries fail Summary validation. Failed verification, blocked states, residual risks, and genuine gaps retain their existing warning or red behavior.

## Safety and privacy

Task Outcome does not manufacture scores, productivity, time, money, percentages, or trust claims. Avoided Impact is conditional and requires Finding/Risk/Intervention/Stop/Resolution/Test evidence. Residual and accepted risks remain visible. Secrets, credentials, private keys, and unnecessary evidence details do not belong in the PR presentation. Self-congratulatory claims such as “dramatically improved project quality” or “saved a lot of time” are rejected unless backed by permitted quantitative evidence; the generator does not produce them.

The full report is not copied into Cockpit Status or a pull request. The PR fragment is opt-in through Project Profile reporting policy and uses an allowlist. Provider PR state and release evidence remain platform or release evidence; Markdown presentation is not proof of merge, publication, or security assurance.

## Language

Project Profile `reporting.defaultLanguage` selects the default locale. `reporting.taskOutcome.languages` may explicitly select `ja`, `en`, and/or `zh-CN` (supported aliases are normalized and unsupported values fail closed). The renderer writes only the configured `outcome.<locale>.md` files. JSON keys and the fact source remain English and are not duplicated per language; user-provided evidence prose is not silently translated or replaced by a fallback language.

## Lifecycle

`ai-finish` first validates deterministic active-evidence readiness, including Summary documentation alignment and ownership, before it starts an expensive required quality route. If that readiness check fails, it immediately persists the canonical blocked/red Outcome with the failed gate and recovery condition; it does not run quality merely to rediscover an archive-blocking evidence defect. After quality and Outcome/report generation, Finish validates the same documentation alignment again so later self-referential mutations cannot make a completed state stale. Archive moves Outcome artifacts transactionally with the Work Item. Event corrections are append-only.

After a validated active Outcome exists, `ai-finish` emits a clearly delimited
conversation/CLI handoff in the requested `REPORT_LANGUAGE`. This happens for
both a successful finish and a fail-closed finish that persists a blocked
Outcome, so a failed gate does not hide the decision facts behind only a file
path or terse diagnostic. The handoff is rendered from the persisted Outcome;
it does not create a second fact source. CLI output cannot authenticate that a
human read or approved the report. The handoff also keeps archive explicit:
`--archive` is a separate lifecycle request and must follow the direct report.

Verification retries are represented as two bounded views. `verification` keeps
the latest result for each check, while failed attempts replaced by a later
attempt are retained in the optional Summary `verificationHistory`. Before
archive, `ai-finish` rebuilds the Outcome and Human Benefit Report after final
stabilization. A failed attempt followed by a passing attempt therefore appears
as an evidence-bound resolved stop and resolution, not as a current blocker;
the latest failed attempt remains a red stop with its recovery condition. This
projection is deterministic, and the history is evidence rather than a claim
that a person read a UI receipt.

After the PR has merged, `make ai-close-work-item TASK=<task>` verifies provider ownership, base synchronization, and cleanup facts, then generates and validates a separate Closure Receipt before either Work Item branch is deleted. The receipt names the archived Outcome, merged PR, merge commit, final base commit, cleanup intent, and the worktree from which the next Work Item may continue. It also checks local branches, local worktrees, and remote branch absence; any residue is a blocking red condition with its exact location and recovery action. A missing or invalid Outcome/Receipt fails closed. The assistant must surface that receipt in its Work Item completion report; it is not a replacement for provider evidence.

This rule applies prospectively. Historical archive bundles are not rewritten merely to add a newer report format.

See [Task Outcome Report Self-Check](task-outcome-report-self-check.md) for the current implementation boundary and known gaps.
