---
author: Ray
title: "Distribution"
description: Distribution and integrity reference for AI Cockpit.
keywords:
  - ai-cockpit
  - distribution
  - integrity
  - install
  - release
---

# Distribution

AI Cockpit distribution is versioned through the published installer and release metadata. Use this page when you need installer flags, integrity capabilities, or local-install details that do not belong in the main adoption flow.
The documented quick-install path resolves public release metadata first and then lets the installer use its own repo or source selection knobs. Public network access to the release metadata is required for that bootstrap step. Private or internally mirrored deployments should use the local-install or configured-source flow instead.

## Verification cost and release-wait diagnostics

During implementation, use `make ai-verify-focused CONTRACT=<contract> SUMMARY=<summary>` to inspect changed-scope task checks. Before a PR or release, use `make ai-verify-full CONTRACT=<contract> SUMMARY=<summary> STAGE=pr` or `STAGE=release`; these stages remain full gates.

Every common quality entrypoint provisions a worktree-local `.venv` before gates run when that environment is missing, unusable, or its direct Ruff version differs from `requirements-dev.in`. Provisioning installs only `requirements-dev.lock` with `--require-hashes`, rechecks the direct pin, and fails closed if it cannot converge. A globally installed formatter or linter is never accepted as equivalent evidence; this makes a fresh linked worktree reproduce the same toolchain rather than requiring a maintainer to repair it by hand.

The release workflow reports the exact source commit, dependent workflow run IDs, elapsed wait time, timeout window, and a diagnostic notice while waiting for exact-SHA smoke or compatibility evidence. A timeout remains fail-closed; diagnostics do not convert a pending or failed run into success.
The release job uses the fixed standard GitHub-hosted `ubuntu-latest` runner. It does not read an organization-level runner variable, select a self-hosted runner, or route publication through a repository-specific runner label. CodeQL and other security-owned workflows remain governed by their own runner configuration; this fixed label applies only to the release job.
SBOM and provenance release evidence must be generated with an explicit source commit (`--source-commit` or `SUPPLY_CHAIN_SOURCE_COMMIT`). The local release-tag fallback exists only for compatibility and never derives evidence identity from the current `HEAD`. The source-bound release archive is serialized by `scripts/release_archive.py`, which uses Git only to select export-ignored paths and Python to write stable tar/gzip bytes. Mutable release projections (`release.json`, `next-release.json`, `release-state.json`, and `release-digests.json`) stay outside the archive: embedding the digest manifest would create a self-reference because the manifest hashes `release.json`, which carries the archive SHA. The workflow therefore builds the archive first, binds its final SHA into `release.json`, then regenerates the public digest manifest and verifies the two public assets independently. Preflight, freeze finalization, and the Hosted workflow must use this same builder; `git archive` bytes are not treated as portable evidence across runner Git versions.
The release workflow treats committed `.ai/cockpit/sbom.json`, `provenance.json`, and `release-digests.json` as candidate baselines only. `release.json` declares `releaseEvidenceAuthority: release-assets-v1`, so the public checker must inspect the published Release Assets before accepting final evidence. After checking out the immutable `SOURCE_COMMIT`, it runs `check_supply_chain.py release-assets`, verifies that every generated provenance and digest subject names that exact commit, runs strict smoke verification for that source commit, and only then creates the tag and Draft Release. While the Release is Draft, the workflow retrieves its named assets through an authenticated GitHub asset API path rather than a public download path, then `verify_quick_install_release.py` validates the exact tag, canonical archive, installer digest, and immutable verified capability. Candidate provenance from a previous release attempt must not be treated as final proof for the current release.

## PR-first release sequence

Every release attempt has one immutable identity tuple: `sourceCommit` is the merged default-branch commit, `tagTarget` must equal it, `metadataCommit` is the commit that contains the candidate metadata (and must be explicit), and `releaseTag` is the requested tag. `HEAD` is not published identity evidence. Candidate freeze metadata is finalized in premerge mode after the Work Item is archived, on the dedicated branch; the candidate `HEAD` materializes canonical content, while controlled default-branch references defer exact identity resolution until after merge. Export-ignored Work Item and release metadata let a clean merge preserve canonical content without a post-close write to protected `main`.
The premerge finalizer calculates `sourceTree`, `archiveSha256`, and `installerDigest` from the clean candidate `HEAD`, not the still-old remote default branch. Hosted release preflight resolves the controlled source reference after PR merge, checks out that exact commit detached, and independently recalculates canonical content and the exact `install.sh` digest. If candidate and merged calculations disagree, publication stops before tag mutation and the process must be corrected before retry.
Changes enter `main` through a pull request. Both `smoke` and `compatibility` also run on `main` pushes, so the commit selected for release has fresh repository-level and cross-platform evidence. Maintainers dispatch `.github/workflows/release.yml` with a new tag and the exact verified default-branch SHA. The workflow resolves the remote symbolic `HEAD`, fetches `origin/<default-branch>`, and rejects a feature-branch or ambiguous source. It records Source Commit, Remote, Default Branch, and Run ID in `release-source.json`, rejects existing tags, requires successful smoke and compatibility runs for that SHA, verifies `release.json`, and only then creates the tag and GitHub Release.

The historical release tag is immutable evidence and is not rewritten. A release-preparation PR may declare exactly the next patch tag as pending publication; it must pass local metadata and evidence checks without claiming that the tag already exists. After the PR merges, maintainers dispatch `.github/workflows/release.yml` with the exact verified `main` SHA. The workflow requires `release.json.releaseTag` and source `.ai/cockpit/version.json.releaseVersion` to match the requested tag, runs strict smoke before mutations, creates the immutable tag and Draft Release, and exercises the real tagged Quick Install before publishing the Draft. The Candidate PR's preparation snapshot is the source-bound release evidence for the merged tree because its premerge freeze is generated after archival and the archive boundary is stable. The workflow resolves the remote symbolic default branch once, binds `sourceCommit`, `tagTarget`, and `metadataCommit` to that commit, and runs release preflight before dependencies, provider CI, tag creation, or publication. A supplied `source_commit` is only an equality assertion; a stale value fails closed. If an immutable tag is found to be invalid after creation, do not move, delete, or republish it. Quarantine any associated GitHub Release as Draft, record the failed evidence, repair the generator and pre-publication gates through a Work Item and PR, then publish the next patch as the corrective release.

An accessed Draft is immutable failure evidence: record it as unavailable in
`release-state.json`, never silently delete it, and advance the next candidate
past that reserved tag. This gives future adopters a distinct corrected version
rather than an ambiguous retry of an accessible failed artifact.
This release flow applies to the template repository. An adopter project must create its own installation or upgrade branch from its own remote default branch and consume the published release tag. The adopter's installation or upgrade is a separate Work Item and PR in the adopter repository; it does not branch from the template repository's `main` or share the template release PR.

## Archive evidence index

`archive/index.json` is an additive discovery index maintained by `archive-work-item`. It records each Work Item's identity, archive sequence, relative Contract/Summary paths, and file hashes so tooling can discover historical evidence without parsing every Summary. The archived Contract and Summary remain authoritative; the index is disposable and may be rebuilt from them if needed.

The development lock is generated from the committed `requirements-dev.in` input with `pip-compile --generate-hashes --allow-unsafe`. The SBOM reports workflow Action occurrences, all version-pinned lock entries, and the direct/transitive split recorded by pip-compile's `via` annotations. Every locked package must carry at least one SHA-256 artifact hash; CI installs with `pip install --require-hashes` so an unlisted artifact fails closed.

The published `release-digests.json` also contains one correlation record. It records the workflow Run ID, workflow Run SHA, source commit, release tag, and the generated SBOM/provenance digests. Its `artifacts.release.json` entry is the SHA-256 of the final public `release.json` asset, after the archive SHA and all runtime projection fields are complete. The release workflow and public distribution checker download both public metadata assets and reject missing Run IDs, Run SHA or tag mismatches, and artifact digest mismatches before tag or publication mutations are accepted. Evidence from another run or source commit must not be mixed into a release.
The companion `ci-release-evidence.json` is the independent CI authority. It records the provider Workflow Run ID, Head SHA, Required Job Names, per-job and overall Conclusions, failure reasons, artifact digests, SBOM, Provenance, and the Head-to-Merge relationship. Verified and published claims require this record; PR Body text and agent/chat claims are never evidence. See [CI and Release Evidence](ci-release-evidence.md) for the schema and state boundary.
The generated `.ai/cockpit/release-digests.json` manifest binds the lock, SBOM, provenance, installer, and release metadata to one source commit and records their SHA-256 digests. `make check-release-evidence` verifies that binding and fails on drift.
The release workflow also runs `make check-lockfile-reproducibility`, which regenerates the hash-enabled lock from `requirements-dev.in` and fails on byte drift before publication. The Make target invokes `$(PYTHON) -m piptools compile` through the interpreter selected by the repository (`.venv/bin/python` when present, otherwise `python3`); it does not assume that a `pip-compile` executable exists beside that interpreter. Both the blocking compatibility workflow and the release workflow install the same pinned pip-tools bootstrap before running the target on a clean Ubuntu runner, so missing lockfile-tool dependencies or regenerated lockfile drift are visible as explicit failures before tag mutation.

When `releaseEvidenceAuthority` is `release-assets-v1`, the public checker downloads `release.json`, `sbom.json`, `provenance.json`, and `release-digests.json` from the tagged GitHub Release. It validates the final public `release.json` bytes against `release-digests.json.artifacts.release.json`, validates source-bound SBOM/provenance hashes from the published manifest, and checks exact tag/commit identity; those runtime assets are intentionally allowed to differ from candidate baselines committed before the immutable source SHA existed. Missing, altered, malformed, unsafe, cross-tag, or cross-commit evidence is rejected before exercising the installer.
Compatibility support claims are split between a fixed-version blocking baseline and separately reported hosted ecosystem probes. The baseline pins Python 3.11/3.14, Go 1.24.4, Rust 1.86.0, Node 24.11.1, Java 21, Ruby 3.4.2, PHP 8.4, Gradle 8.12, and the declared mobile fixture levels; it runs on the `ubuntu-latest` and `macos-latest` labels where applicable. Only that baseline is release-blocking. The `latest-ecosystem-probe` lane requests current Stable/Latest tools and is explicitly non-blocking; its result is exploratory evidence and must not be described as verified baseline support. Hosted labels can move independently of the pinned tool versions, so Ubuntu/macOS image changes remain an external compatibility risk.

## Published Capabilities

<!-- release-capabilities: auditable-adoption,sha256-verification -->

The documented public release is defined in `release.json`. Release preparation may use the separate `next-release.json` candidate record, which must be marked `releaseState: candidate`, `published: false`, and exactly one patch after the published tag. `release.json` intentionally omits self-referential source/archive fields: Quick Install resolves the immutable tag target, while `release-source.json` and provider-bound evidence record the exact source commit. `.gitattributes` excludes the mutable release projections from the source archive so the published archive SHA is independently reproducible. The candidate record cannot redirect the public installation entry; publication occurs only after exact-source verification.

Release progression has one canonical record: `release-state.json` (`schemaVersion: 1`, `canonical: true`). It owns the `development` → `candidate_prepared` → `candidate_verified` → `release_published` state machine, release tag, previous release, source identity, and evidence references. `release.json` and `next-release.json` are explicitly declared projections: the former is the published installer contract and the latter is the unpublished candidate projection. They are not independent release truths. `evidenceStatus` describes whether provider evidence is pending, verified, or published; `evidenceBundleDigest` is `null` until provider evidence exists and must be a real SHA-256 for verified or published states. `make check-release-state-consistency` rejects missing canonical markers, projection remapping, prose placeholders, and invalid status/digest combinations. Failed verification must leave the state and tag unchanged.

Installer and upgrade flows intentionally exclude the template's `sbom.json`, `provenance.json`, and `bandit_low_risk_baseline.json`. Those files describe the template release; an adopter must generate and verify project-owned evidence after adoption.

- Public Quick Install verifies the immutable tagged source commit, installer digest, and exact downloadable release-archive asset declared by `release.json`; missing or mismatched evidence fails closed. Source identity is not accepted from a self-referential field in the archive.
- `AI_COCKPIT_TEMPLATE_SHA256` is an optional additional assertion and cannot replace the published archive metadata.
- `make check-release-distribution` validates the documented distribution contract against the real installer.
- Worktree capabilities are only public when the installed release passes the published distribution check.
- The repository also maintains supply-chain evidence checks for the dev dependency lockfile, SBOM/provenance baselines, and secret scanning. The local `make check-secret-scanning` command is a fast lightweight guard over the current checkout. The release-blocking `smoke` workflow additionally builds and runs Gitleaks from a pinned upstream commit over the full checkout history as delegated evidence; the repository does not claim that local pattern matching replaces professional secret-scanning coverage or that GitHub Secret Scanning is enabled by repository content alone.

The digest manifest proves repository-internal consistency only. The release archive asset and its SHA256 are the public Quick Install binding, not a cryptographic signature or provenance attestation; a release pipeline must provide an independently verifiable signature or Sigstore/provenance attestation and publish its verification material. Treat caller-provided SHA256 comparison and this manifest as additional checks, not as an external trust root.
An unreleased worktree may regenerate its local SBOM, provenance, and digest manifest before the next public tag. `check-release-distribution` validates the historical tag's own evidence separately and does not equate those unreleased digests with the tag's public claims.

## Installer Options

```text
--dry-run          Show actions without writing files.
--force            Overwrite existing AI Cockpit files.
--upgrade          Back up and replace managed runtime, policy, and agent marker files.
--upgrade-with-active
                   Permit a high-risk upgrade while active Work Item JSON exists.
--replace-glossary Back up and explicitly replace the project-owned .ai/glossary.md.
--create-adoption Create the first auditable adoption Work Item; requires clean committed Git state.
--with-examples    Copy examples/ into the target repository.
--update-makefile  Append "include Makefile.ai" to the target Makefile.
```

Without `--update-makefile`, the installer writes `Makefile.ai` and `Makefile.ai.stack` but does not modify the host `Makefile`.

The canonical non-interactive adoption flags remain together:

```sh
sh "$INSTALLER" --stack "$STACK" --update-makefile --create-adoption
```

## Installed Runtime Surface

The installed artifact contains the version-bound lifecycle scripts required by `Makefile.ai`: `ai_install_status.py`, `ai_lifecycle_facts.py`, `ai_upgrade_proposal.py`, `ai_upgrade_apply.py`, `ai_rollback.py`, `ai_disable_enable.py`, `ai_uninstall_facts.py`, `ai_uninstall_proposal.py`, and `ai_detached_uninstaller.py`. The matching targets are read-only status/facts, governed update proposal/apply, rollback proposal, disable/enable state transition proposal, and preserve-evidence uninstall facts/proposal/digest-confirmed detached execution. Purge is not implemented by this executor. A clean Adopter Fixture is the authority for whether the surface is actually installed and executable; source-tree presence alone is not an installed capability claim.

## Local Install

From a local clone:

```sh
/path/to/ai-cockpit-template/install.sh --stack rust --update-makefile
```

## When To Use This Page

- You need the installed distribution behavior, not the adoption workflow.
- You need a canonical place for installer options and integrity notes.
- You are documenting release-specific distribution details for maintainers or integrators.
## Next release candidate

The repository published projection, stable provider Releases, immutable Git
tags, and the unpublished candidate are separate facts. A semantic Git tag
reserves its version even when no stable GitHub Release exists; it must never
be called published or reused as a candidate. `release-state.json` records
unavailable versions with a reason and evidence reference, and the next
candidate must be exactly one patch after the highest reserved version.

At `candidate_prepared`, final source identity is deliberately deferred:
`sourceBinding` is `deferred_to_release_finalization` and `sourceCommit` is
null. Later release finalization binds the exact source commit, tag target,
metadata commit, archive, freeze, digests, SBOM, provenance, and provider
evidence. A candidate may become public only after those bindings are verified
and the workflow validates the real tagged Quick Install while the GitHub
Release is still Draft.
The candidate records a preparation snapshot, but the release workflow resolves `SOURCE_COMMIT` from the freshly fetched default branch at dispatch time. The hosted boundary explicitly verifies that detached `HEAD` equals that SHA, records the `.gitattributes` identity, and invokes `make check-release-preflight RELEASE_PREFLIGHT_SOURCE_COMMIT="$SOURCE_COMMIT"`; the validator therefore cannot silently fall back to a different `HEAD`. The default-branch remote-tracking ref is fetched to resolve controlled `origin/main` metadata references in a fresh runner. An omitted `source_commit` input uses the resolved commit; a supplied value is only an assertion and must match it exactly. Detached checkout, tag, provider workflow, SBOM, provenance, and digest evidence must all reference that same immutable source before promotion. A stale or mismatched assertion fails closed before checkout or publication. Missing provider assets remain missing evidence; this release does not change the enterprise-security NO-GO boundary.

Before publication, maintainers run `make check-release-readiness` and dispatch a
same-SHA release rehearsal. The rehearsal executes the exact-source preparation,
runtime freeze, strict preflight, dependency, CI, supply-chain evidence, and
strict-smoke path, then stores a private Actions receipt. A rehearsal is not a published release:
it cannot create a tag, GitHub Release, or public asset. The
actual release must verify a successful receipt with the same resolved source SHA
and requested tag before any immutable mutation. If main changes afterwards, run
a new rehearsal for that SHA; do not treat an old preparation snapshot as a reason
to repeatedly create freeze Work Items.

For an unexpired same-source rehearsal, publication consumes the strict-smoke
result instead of dispatching it again. This is not a weaker verification path:
the receipt must exactly bind the Git tree, tag, successful jobs, test collection
and shards, coverage/source set, provider artifact digests and its own integrity
digest. A missing, stale, cancelled, failed or mismatched field stops publication
before the tag; runtime release checks and Draft Quick Install remain mandatory.

Readiness normally requires no active Work Item. The sole exception is the one
explicitly authorized `repository_release.publish` Work Item that records the
publication evidence; it must be the only active Contract. That exception is
evidence custody only, never a bypass of rehearsal or release gates.
