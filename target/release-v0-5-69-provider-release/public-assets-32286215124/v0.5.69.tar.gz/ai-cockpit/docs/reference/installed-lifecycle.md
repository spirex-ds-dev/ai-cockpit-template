---
author: Ray
title: "Installed Lifecycle Facts"
description: "The durable installation facts used by later governed lifecycle operations."
keywords:
  - installed-lifecycle
  - manifest
  - ownership
  - rollback
---

# Installed Lifecycle Facts

An installation may record durable lifecycle facts under `.ai/install/`; their presence is an installed-repository fact, not proof that every update, rollback, disable/enable, or uninstall path is complete. The current capability boundary is maintained in the [Capability Truth Matrix](capability-truth-matrix.md):

- `manifest.json` records the installation identity, source/version, timestamp, installed paths, source paths, ownership class, installed SHA-256 digest, current digest, and `projectModified` fact for every file.
- `version.json` records the installed distribution and Contract schema versions, Runtime State, and the SHA-256 binding to the manifest.
- `release-identity.json` records either a local-source boundary or the immutable tagged-release tuple: canonical tag, release version, source/tag/metadata commit, artifact digests, and its binding to the manifest. A tagged installation is rejected before writes unless all of those release facts agree.
- `managed-regions.json` records Shared files, ownership class, installed/current digest, modification state, and their installation-time full-file boundaries.
- `rollback-baseline.json` records the installation-time digest baseline used by later update and rollback proposals.

Ownership is explicit: `template`, `project`, `shared`, `generated`, or `historical`. The installer does not infer permission to overwrite or delete project-owned or historical content from a path alone. `scripts/ai_install_facts.py` validates that all fact files exist, agree on one installation identity, and bind ownership, release identity, and baseline digests; missing, malformed, stale, or tampered facts fail closed while current project drift is reported as evidence.

These facts are a repository record, not an identity system, approval system, immutable audit ledger, sandbox, or enterprise assurance claim. Update, migration, rollback, disable/enable, uninstall, and purge behavior is governed by their own Work Items and must consume validated facts.

## Installer domain boundary

The compatibility command remains `scripts/install_ai_cockpit.py`. It is a
thin CLI adapter: it does not write adopter files itself and delegates to the
installer application boundary. The staged domain package at
`scripts/installer/` makes the review boundary explicit:

- `inspection`, `git_state`, and `planning` collect or render read-only facts.
- `confirmation` and `transaction` require an explicit approved confirmation
  before an executor can act on a plan.
- `ownership`, `rollback`, and `evidence` carry typed review facts rather than
  inferring permission from a pathname.
- `application`, `presentation`, `upgrade`, and `cli` compose the compatible
  installer surface without changing its policy.

This is a staged refactor. It preserves the established installer behavior and
does not claim that an adopter installation, provider operation, or release
has been executed merely because a plan was inspected.

## Ownership decisions

Ownership is an installation fact, not a path heuristic. The supported classes are:

- `template`: distributed content that may be refreshed by a governed update.
- `project`: adopter configuration or business content that is preserved by default.
- `shared`: files that may change only inside explicit managed regions.
- `generated`: lifecycle-generated runtime or status content.
- `historical`: archived evidence that is immutable and never overwritten.

Shared regions use matching markers such as `# BEGIN AI COCKPIT MANAGED REGION: ci` and `# END AI COCKPIT MANAGED REGION: ci`. Missing, duplicate, nested, unmatched, or drifted markers produce a fail-closed decision. Unknown ownership, project content, and historical evidence are never mutation-authorized by the ownership evaluator.

Use `make ai-cockpit-version` for the installed version and `make ai-cockpit-update-check TARGET_VERSION=vX.Y.Z` for a read-only update check. Both commands consume validated facts, report `readOnly: true`, and return an error state without writing files when facts or Release Evidence are missing or invalid.

## Three-way update proposals

Before any update is applied, generate a reviewable proposal from the installed baseline (Old Template), candidate release (New Template), and current project:

```text
make ai-cockpit-update-propose OLD_TEMPLATE=/path/to/old NEW_TEMPLATE=/path/to/new UPGRADE_ID=upgrade-2026-07
```

The proposal is written only to `.ai/upgrade/proposals/<upgrade-id>.json`; generation does not modify Runtime or project files. Each change is classified as an unchanged or safe template update, project-modified conflict, project-owned file, shared managed region, new/removed template file, generated file, historical file, or fail-closed conflict. The proposal also binds installed and candidate manifest hashes, Release Evidence, rollback baseline, migration, recalibration impact, a standard Work Item handoff, PR handoff, rollback evidence, and a resume condition. Safe files may be considered by the later confirmation/apply Work Item, while project-owned, shared, historical, generated, and removed content requires explicit review.

Apply is a separate confirmation boundary:

```text
make ai-cockpit-update-apply PROPOSAL=.ai/upgrade/proposals/upgrade-2026-07.json
make ai-cockpit-update-apply PROPOSAL=.ai/upgrade/proposals/upgrade-2026-07.json CONFIRM=APPLY
```

The first command is read-only and returns the confirmation options. The confirmed command checks repository drift, creates `.ai/upgrade/snapshots/<upgrade-id>/`, applies only safe/new files, retains project-owned and historical content, updates validated facts, and writes an ordered Update Summary. Drift or unresolved conflicts stop before any write. Migration, generated regeneration, readiness, and smoke-test steps remain explicit deferred stages for their dedicated Work Items.

## Schema migration

Project-owned configuration migrations use a versioned registry and produce a plan containing old/new fields, defaults, non-migratable content, policy impact, and reconfirmation items. Policy strengthening, critical-threshold changes, baseline changes, and other high-risk changes return `needs_human_confirmation`; unsupported reverse migrations return `partial_rollback` and do not write configuration. The migration planner is `scripts/ai_schema_migration.py` and is intentionally separate from update application.

## Rollback snapshot and execution

Before an update mutates Runtime or Managed Regions, a snapshot is created under `.ai/upgrade/snapshots/<upgrade-id>/`. It contains `manifest.before.json`, `version.before.json`, `release-identity.before.json`, `managed-regions.before.json`, Runtime restore sources, the Project Config hash, the Migration Plan, and rollback instructions. Rollback first validates the current installed manifest, then emits a confirmation-gated proposal. Confirmation restores only snapshot-owned Runtime and Managed Region content; Project-owned code and configuration are preserved even when they drifted after the update. Missing snapshots or current-installation drift are `blocked`. A non-invertible migration is `partial_rollback` and lists remaining manual operations; no write occurs in either state.

## Disable and enable

The installed `ai-cockpit-disable` and `ai-cockpit-enable` entrypoints model a
reversible state transition and write a result JSON. They do not update the
input file or canonical installed state. The disable result retains Runtime,
Policy, Evidence, Archive, and Managed Regions and proposes a blocking entry.
The enable result requires Runtime Integrity, Manifest, Project Profile,
Policy, and Adoption Readiness checks. A target repository must not claim an
actual state transition until it has reviewed and persisted the result through
an evidenced canonical-state integration.

## Uninstall proposal and preserve-evidence mode

The installed preserve-evidence path has three public Make entrypoints:

1. `ai-cockpit-uninstall-facts` validates the installation fact bundle and
   current filesystem. It rejects malformed, absolute, traversing, duplicate,
   symlinked, missing, modified, or unknown-owned managed paths.
2. `ai-cockpit-uninstall-propose` emits a zero-Runtime-write proposal. Its
   canonical `proposalDigest` binds repository identity, installation ID,
   session ID, mode, deletion list, preservation list, and receipt path.
3. `ai-cockpit-uninstall-execute` copies the executor and its validation
   modules to a system temporary directory, then starts that detached copy.
   Direct internal execution is blocked. The detached process re-collects facts
   immediately before mutation and accepts only the exact confirmed digest.

Only unchanged Template-owned files listed by the validated installation
manifest are removable. Project, Shared, Generated, Historical, modified,
unknown-owned, protected, unlisted, escaping, and symlinked paths remain
untouched. The receipt is outside the deletion set and records detached
execution, actual removed/preserved/missing/failed paths, partial failure
recovery, and post-state verification. `runtimeRemovalVerified: true` appears
only when every requested Runtime path is absent and every preserved path
remains. An existing receipt blocks replay.

`disable` remains a separate public state-result entrypoint and is rejected by
the uninstall proposal. `purge` remains unsupported by the preserve-evidence
executor and returns `blocked`; no public purge filesystem-removal entrypoint
exists. A future purge implementation must verify an Evidence Export Bundle,
display exact irreversible impact, require separate confirmation, protect
project-owned and audit evidence, and emit its own verified receipt.

## Cockpit, CLI, and Summary alignment

## Read-only installer conflict matrix

`scripts/installer/conflict_matrix.py` provides a read-only inspection view of
common installation conflicts. Its findings use `safe`, `warning`,
`requires_review`, and `blocked`; they are evidence for an installer plan, not
permission to mutate a target. A blocked finding (for example an active install
lock, reserved Make target, active Work Item, symlink, or escaping path) must
result in zero transaction writes. Recovery and approval remain separate
transaction responsibilities.

The generated Cockpit Status is the user-facing projection of Lifecycle Facts. It must show installed/target version, Runtime State, Project Profile, conflicts, rollback state, disable state, uninstall preparation, and residual risk. A lifecycle Summary binds Upgrade ID and Manifest Hash to change counts, Migration Plan, Snapshot, user decisions, verification results, and residual risk. Commands and docs use the same states (`active`, `disabled`, `needs_human_confirmation`, `blocked`, `partial_rollback`, `purged`); an unavailable tool is recorded as `not_run`, never implied to have executed.

Cross-stack E2E evidence uses three explicit kinds: `local_real_execution`, `not_run`, and `simulation`. A real Python fixture must cover the lifecycle phases; TypeScript/Java lanes are recorded as `not_run` when their toolchain is unavailable. Manifest, Schema, Rollback, and Uninstall evidence carries the stack and phase so a simulated result cannot be presented as an execution result.

The lifecycle safety gate tests both negative and legal boundary cases. Silent overwrite/delete, drift, unconfirmed operations, and forged execution claims return `blocked` with `state`, `reason`, `evidence`, `resumeCondition`, and `policyReference`. Legal no-op, documentation, sandbox mock, and cancellation cases may return `allowed`. A failed safety gate blocks release and plan cleanup.
