---
author: Ray
title: "Enterprise Security and Compliance Boundary"
description: Separates AI Cockpit governance evidence from external enterprise controls.
keywords:
  - ai-cockpit
  - security
  - compliance
  - trust-layer
---

# Enterprise Security and Compliance Boundary

The machine-readable **observed control evidence** inventory and adopter handoff checklist are maintained in [`docs/reference/enterprise-control-matrix.json`](reference/enterprise-control-matrix.json) and [`docs/reference/enterprise-control-checklist.md`](reference/enterprise-control-checklist.md). A control is `not_verified` until a current, scoped external receipt is supplied; a repository-local record never becomes provider or enterprise control evidence.

AI Cockpit provides repository governance evidence: scoped Work Items, deterministic checks, test and supply-chain reports, decision records, and lifecycle closure. These records support review; they are not enterprise security certification.

| Concern | AI Cockpit evidence | Required external control |
| --- | --- | --- |
| Change governance | Contract, scope, checks, PR and branch closure | Organization branch protection and access governance |
| Software quality | Tests, lint, type, security and supply-chain checks | Independent risk acceptance and security review |
| Identity and authorization | Recorded reviewer/decision metadata | Trusted identity provider, least privilege, audit retention |
| Runtime isolation | Not provided by the template | Sandbox, policy enforcement, network and host controls |
| Compliance certification | Not provided by the template | Applicable legal, regulatory, contractual assessment |

The template therefore remains conditional for adoption and is not a substitute for enterprise security or compliance controls. No claim here establishes runtime isolation, trusted identity, cryptographic proof, or certification.

The deterministic checks cover only the finite, externally evidenced known-risk vocabulary implemented by the repository. They are not a universal semantic-risk classifier and do not turn governance records into Sandbox, identity, immutable-audit, or enterprise-compliance guarantees.
