---
author: Ray
title: "First Work Item"
description: First governed task walkthrough after AI Cockpit adoption.
audience:
  - adopter
  - contributor
status: current
authority: canonical
lastVerifiedBy: capability-truth-matrix
capabilityClaims:
  - repository_governance_layer
keywords:
  - ai-cockpit
  - first-work-item
  - adoption
  - verification
---

# First Work Item

Use this page after installation and validation succeed. Complete the [Adopter Configuration](adopter-configuration.md) checklist before treating the repository as production-ready, then use this page for the first governed task from start to finish.

## Start a Governed Task
Each governed task uses one Work Item, one dedicated branch, and one pull or merge request. In this template repository, start from the latest `origin/main`. In an adopter project, start from the latest commit on that project's discovered remote default branch; do not assume the remote is `origin` or the branch is `main`. Record the chosen remote, branch, and base commit in the Contract.

If Preflight reports missing evidence, ambiguous intent, scope expansion, a critical-domain operation, or a governance bypass, stop. Do not continue because an agent explanation sounds plausible. Record the decision request, choose a safe local alternative or provide independently verifiable evidence, then re-run Preflight before resuming.

```sh
make ai-start TASK=example_change TITLE="Example change" MODE=code
```

`ai-start` requires the target to be a Git repository with at least one commit so `baseCommit` can identify a trustworthy diff baseline. For a new repository, create and commit its initial files before running this command. The installer prints a warning when this prerequisite is not met.

When you run `make ai-start TASK=<task> TITLE="..." MODE=code`, the command shows a Preflight Review before implementation begins. That review is advisory by default, but if it returns `needs_human_confirmation` or `not_ready`, the agent workflow must pause and report the review to the user before coding continues.

Edit the generated Contract:

```text
.ai/work-items/active/example_change.contract.json
```

Before changing project files, replace the starter placeholders and confirm this minimum checklist:

- `scope` contains every file or path pattern the task may change, and `outOfScope` states explicit boundaries.
- `sources`, `acceptance`, and `verification` describe the evidence, done conditions, and registered checks.
- `unknowns` is empty, `notCodable` is `false`, and `executionDecision.status` is `continue`.
- `agentCapability.canImplement` and `agentCapability.canVerify` are `true`; human decisions remain explicit.
- Run the canonical pre-implementation checkpoint with the Contract and Summary paths:

  ```sh
  make ai-prepare-implementation \
    CONTRACT=.ai/work-items/active/<task>.contract.json \
    SUMMARY=.ai/work-items/active/<task>.summary.json
  ```

When the task is long-running, record a `before_finish` checkpoint in the Summary before running the finish flow.

Update the Summary before finishing:

```text
.ai/work-items/active/example_change.summary.json
```

Run the finish flow:

```sh
make ai-finish TASK=example_change ARCHIVE=true REPORT_LANGUAGE=en
```

`ARCHIVE=true` is required for this command to archive the Contract/Summary pair. After a successful finish, commit the archive bundle, push the Work Item branch, open and merge its PR, then run `make ai-close-work-item TASK=<task>`. A successful walkthrough ends only after closure verifies archived evidence and merged PR identity, synchronizes the base, deletes the owned local and remote branches, and confirms a clean repository. Do not delete the corresponding remote or local work branch directly. Installation and upgrade tasks follow the same rule, but their source is a published template release tag recorded in the adopter project's Work Item.

The required order is: finish and archive, commit, push, open and merge the PR, then close the Work Item. Do not merge the branch into local `main` before the PR, and do not enable an automatic branch-delete option that removes it before closure. `ai-close-work-item` performs the base synchronization and branch cleanup as one verified lifecycle step.

Complete the lifecycle with the merged PR still identifiable from the Work Item branch:

```sh
make ai-close-work-item TASK=example_change
```

The command switches to the repository's discovered base branch only after verifying the archived evidence and merged PR, synchronizes it with `--ff-only`, then deletes local and remote work branches. It exits nonzero and reports the Work Item as not closed if any precondition or cleanup verification fails.
